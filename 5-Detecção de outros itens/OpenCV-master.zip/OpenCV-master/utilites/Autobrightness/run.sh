clear 

echo "Running plugin.... (Press Esc to exit)"

sudo chmod 777 /sys/class/backlight/acpi_video0/brightness

./ab


